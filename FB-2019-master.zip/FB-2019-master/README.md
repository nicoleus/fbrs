# fbr hacking Facebook tool

# follow installation 
# $: git clone https://github.com/Cabdulahi/fbr
# $: cd fbr
# $: bash install.sh
# $: python2 fbr.py

@coded By Cabdulahi Sharif Gsm

